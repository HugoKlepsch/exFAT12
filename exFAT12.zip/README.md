# exFAT12

A gentle introduction to the exFAT file system in FASM.